Sitio generado automáticamente para Juan Roldan (Juan Diseño Gráfico).
Archivos:
- index.html : página principal
- assets/juan_photo.jpg : foto usada en el encabezado (si existe)
- assets/works/ : carpeta con imágenes extraídas de TRABAJOS REALIZADOS.zip

Subir todo el contenido de la carpeta 'portfolio_site' a un hosting (o abrir index.html localmente) para ver el sitio.
WhatsApp link uses: https://wa.me/5493856122212
Instagram: https://instagram.com/juancroldan__

Si querés que ajuste texto, layout, o colores, respondé en el chat y hago los cambios.
